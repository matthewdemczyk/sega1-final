public class InitializeInstances{
	public static void main(String[] args){
		Employee o1 = new Employee("Falcao",40,15.50,new Address[]{new Address("Queen",48,"K1P1N2"),new Address("King Edward",800,"K1N6N5"),null,null,null,null});
	}
}